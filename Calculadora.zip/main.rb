# Calculadora de expressões matemáticas

def somar(num1, num2)
  # Função para somar os valores que o usuário digitar
  num1 + num2
end

def sub(num1, num2)
  # Função para subtrair os valores que o usuário digitar
  num1 - num2
end

def muti(num1, num2)
  # Função para multiplicar os valores que o usuário digitar
  num1 * num2
end

def div(num1, num2)
  # Função para dividir os valores que o usuário digitar
  num1 / num2
end

def raizQuadrada(num1)
  # Função para calcular a raiz quadrada do valor que o usuário digitar
  Math.sqrt(num1)
end

def potencia(num1, num2)
  # Função para calcular a potência do valor que o usuário digitar
  num1**num2
end

def calculadora
  # Função calculadora, onde chama as demais funções e inicializa os parâmetros obrigatórios
  # de acordo com o que o usuário digitar
  puts 'Bem vindo à calculadora feita em Ruby

          ───▄▄─▄████▄▐▄▄▄▌
          ──▐──████▀███▄█▄▌
          ▐─▌──█▀▌──▐▀▌▀█▀
          ─▀───▌─▌──▐─▌
          ─────█─█──▐▌█
  '
  sleep(1)
  puts 'Calculadora desenvolvida por BRUNO HSM'
  sleep(2)
  puts '..........INÍCIO DO PROGRAMA................'
  puts 'Digite o primeiro número'
  num1 = gets.chomp.to_f
  puts 'Digite o segundo número'
  num2 = gets.chomp.to_f
  puts 'Digite a operação desejada'
  puts " Digite 1 para soma\n Digite 2 para subtração \n Digite 3 para multiplicação \n Digite 4 para divisão \n Digite 5 para raiz quadrada \n Digite 6 para potenciação \n Digite 0 para encerrar o programa"
  operacao = gets.chomp.to_i

  # Como em Ruby não temos a função Switch, utilizamos a função case/when
  case operacao
  when 1
    puts "O resultado da soma é #{somar(num1, num2)}"
  when 2
    puts "O resultado da subtração é #{sub(num1, num2)}"
  when 3
    puts "O resultado da multiplicação é #{muti(num1, num2)}"
  when 4
    puts "O resultado da divisão é #{div(num1, num2)}"
  when 5
    puts "O resultado da raiz quadrada é #{raizQuadrada(num1)}"
  when 6
    puts "O resultado da potência é #{potencia(num1, num2)}"
  when 0
    puts 'Encerrando o programa'
    sleep(3)
    puts '..........FIM DO PROGRAMA................'
    exit
  end
end

# Chama a função calculadora e inicia o programa
calculadora